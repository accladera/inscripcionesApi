create
    definer = root@localhost procedure sp_inscripcion_selectAll()
SELECT id,usuarioId, carreraId,materiaId
FROM inscripcion;

