create
    definer = root@localhost procedure sp_carrera_insert(IN p_nombre varchar(200))
BEGIN
INSERT INTO carrera(nombre)
VALUES (p_nombre);
SELECT LAST_INSERT_ID() as lastId;
END;

