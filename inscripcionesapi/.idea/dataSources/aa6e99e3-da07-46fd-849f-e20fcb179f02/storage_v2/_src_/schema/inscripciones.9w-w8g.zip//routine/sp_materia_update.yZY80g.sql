create
    definer = root@localhost procedure sp_materia_update(IN p_nombre varchar(200), IN p_semestre varchar(200),
                                                         IN p_precio int, IN p_carreraId int, IN p_id int)
UPDATE materia 
            SET
                nombre = p_nombre,
                semestre = p_semestre,
                precio  = p_precio,
                carreraId = p_carreraId
            WHERE
                id = p_id;

