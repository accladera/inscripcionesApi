create
    definer = root@localhost procedure sp_inscripcion_insert(IN p_usuarioId int, IN p_carreraId int, IN p_materiaId int)
BEGIN
INSERT INTO inscripcion(usuarioId,carreraId,materiaId)
VALUES (p_usuarioId,p_carreraId,p_materiaId);
SELECT LAST_INSERT_ID() as lastId;
END;

