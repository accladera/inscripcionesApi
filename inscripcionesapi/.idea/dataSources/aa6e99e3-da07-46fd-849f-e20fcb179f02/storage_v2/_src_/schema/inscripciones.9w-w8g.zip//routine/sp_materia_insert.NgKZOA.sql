create
    definer = root@localhost procedure sp_materia_insert(IN p_nombre varchar(200), IN p_semestre varchar(200),
                                                         IN p_precio int, IN p_carreraId int)
BEGIN
INSERT INTO materia(nombre, semestre, precio, carreraId)
VALUES (p_nombre, p_semestre, p_precio ,p_carreraId);
SELECT LAST_INSERT_ID() as lastId;
END;

