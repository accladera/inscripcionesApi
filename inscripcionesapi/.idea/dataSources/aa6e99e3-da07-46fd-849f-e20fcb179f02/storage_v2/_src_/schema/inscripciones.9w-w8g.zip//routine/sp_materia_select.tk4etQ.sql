create
    definer = root@localhost procedure sp_materia_select(IN p_id int)
SELECT id, nombre,semestre, precio , carreraId
            FROM materia WHERE  id = p_id;

