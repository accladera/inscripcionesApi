create
    definer = root@localhost procedure sp_carrera_update(IN p_nombre varchar(200), IN p_id int)
UPDATE carrera 
            SET
                nombre = p_nombre
            WHERE
                id = p_id;

