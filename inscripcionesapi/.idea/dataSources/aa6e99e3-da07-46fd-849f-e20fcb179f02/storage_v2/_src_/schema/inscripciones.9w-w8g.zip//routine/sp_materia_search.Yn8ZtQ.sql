create
    definer = root@localhost procedure sp_materia_search(IN p_busqueda int)
SELECT 
    id, nombre, semestre,precio, carreraId
    FROM materia 
                WHERE  nombre LIKE CONCAT('%',p_busqueda,'%') 
                OR semestre LIKE CONCAT('%',p_busqueda,'%');

