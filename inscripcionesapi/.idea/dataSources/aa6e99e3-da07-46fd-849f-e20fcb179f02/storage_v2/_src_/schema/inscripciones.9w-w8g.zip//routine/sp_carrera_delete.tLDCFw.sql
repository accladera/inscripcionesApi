create
    definer = root@localhost procedure sp_carrera_delete(IN p_id int)
DELETE FROM carrera  WHERE id = p_id;

