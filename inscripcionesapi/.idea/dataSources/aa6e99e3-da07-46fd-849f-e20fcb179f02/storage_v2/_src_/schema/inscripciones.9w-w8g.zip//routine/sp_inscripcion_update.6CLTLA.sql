create
    definer = root@localhost procedure sp_inscripcion_update(IN p_usuarioId int, IN p_carreraId int, IN p_materiaId int, IN p_id int)
UPDATE inscripcion 
            SET
            	usuarioId = p_usuarioId,
                carreraId = p_carreraId,
                materiaId = p_materiaId
            WHERE
                id = p_id;

