create
    definer = root@localhost procedure sp_carrera_selectAll()
SELECT id,nombre
FROM carrera;

