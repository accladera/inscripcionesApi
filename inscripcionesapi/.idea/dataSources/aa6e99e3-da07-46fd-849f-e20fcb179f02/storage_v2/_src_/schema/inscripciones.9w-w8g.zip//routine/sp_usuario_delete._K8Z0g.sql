create
    definer = root@localhost procedure sp_usuario_delete(IN p_id int)
DELETE FROM usuario  WHERE id = p_id;

