create
    definer = root@localhost procedure sp_materia_selectAll()
SELECT id,nombre, semestre, precio, carreraId
FROM materia;

