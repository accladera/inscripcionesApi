create
    definer = root@localhost procedure sp_usuario_update(IN p_nombreCompleto varchar(200), IN p_email varchar(200),
                                                         IN p_password varchar(200), IN p_tipoUsuario int,
                                                         IN p_carreraId int, IN p_id int)
UPDATE usuario 
            SET
                nombreCompleto = p_nombreCompleto,
                email = p_email,
                password = p_password,
                tipoUsuario = p_tipoUsuario,
                carreraId = p_carreraId
                
            WHERE
                id = p_id;

