create
    definer = root@localhost procedure sp_inscripcion_search(IN p_busqueda int)
SELECT 
    id, usuarioId, carreraId, materiaId
                FROM inscripcion 
                WHERE  usuarioId  = p_busqueda 		
                OR carreraId = p_busqueda
                OR materiaId = p_busqueda;

