create
    definer = root@localhost procedure sp_inscripcion_select(IN p_id int)
SELECT id,usuarioId , carreraId, materiaId
            FROM inscripcion WHERE  id = p_id;

