create
    definer = root@localhost procedure sp_usuario_selectAll()
SELECT id, nombreCompleto, email, password, tipoUsuario, carreraId
FROM usuario;

