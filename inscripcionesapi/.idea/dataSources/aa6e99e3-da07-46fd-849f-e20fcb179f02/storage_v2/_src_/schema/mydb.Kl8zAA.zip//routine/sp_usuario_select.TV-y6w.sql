create
    definer = root@localhost procedure sp_usuario_select(IN p_id int)
SELECT id, nombreCompleto, email, password, tipoUsuario, carreraId
            FROM usuario WHERE  id = p_id;

