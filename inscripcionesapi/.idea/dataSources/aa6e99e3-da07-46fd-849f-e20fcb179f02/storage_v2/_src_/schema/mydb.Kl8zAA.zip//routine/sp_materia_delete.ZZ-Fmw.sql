create
    definer = root@localhost procedure sp_materia_delete(IN p_id int)
DELETE FROM materia  WHERE id = p_id;

