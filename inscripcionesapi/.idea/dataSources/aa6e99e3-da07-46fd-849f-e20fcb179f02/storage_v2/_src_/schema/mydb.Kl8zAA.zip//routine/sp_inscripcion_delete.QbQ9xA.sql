create
    definer = root@localhost procedure sp_inscripcion_delete(IN p_id int)
DELETE FROM inscripcion  WHERE id = p_id;

