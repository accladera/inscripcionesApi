create
    definer = root@localhost procedure sp_carrera_select(IN p_id int)
SELECT id, nombre FROM carrera WHERE  id = p_id;

