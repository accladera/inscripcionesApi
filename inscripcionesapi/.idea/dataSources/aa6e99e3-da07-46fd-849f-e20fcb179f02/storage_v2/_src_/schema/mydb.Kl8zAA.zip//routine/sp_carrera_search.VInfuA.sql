create
    definer = root@localhost procedure sp_carrera_search(IN p_busqueda varchar(200))
SELECT 
    id,nombre
                FROM carrera 
                WHERE  nombre LIKE CONCAT('%',p_busqueda,'%');

