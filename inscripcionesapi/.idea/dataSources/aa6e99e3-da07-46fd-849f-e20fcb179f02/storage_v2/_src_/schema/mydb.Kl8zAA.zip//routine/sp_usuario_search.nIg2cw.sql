create
    definer = root@localhost procedure sp_usuario_search(IN p_busqueda varchar(200))
SELECT 
    id, nombreCompleto, email, password, tipoUsuario, carreraId
                FROM usuario 
                WHERE  nombreCompleto LIKE CONCAT('%',p_busqueda,'%') 
                OR email LIKE CONCAT('%',p_busqueda,'%');

