create
    definer = root@localhost procedure sp_usuario_insert(IN p_nombreCompleto varchar(200), IN p_email varchar(200),
                                                         IN p_password varchar(200), IN p_tipoUsuario int,
                                                         IN p_carreraId int)
BEGIN
INSERT INTO usuario(nombreCompleto,email,password,tipoUsuario,carreraId)
VALUES (p_nombreCompleto,
        p_email,
        p_password, 
        p_tipoUsuario,
        p_carreraId);
SELECT LAST_INSERT_ID() as lastId;
END;

