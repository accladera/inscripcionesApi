import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
export const CarreraDisplay = (props)=>
{

    const [listaCarreras, setListaCarreras] = useState([]);

    useEffect(() => {
        traerCarreras();
    }, []);

    const traerCarreras = () => {
        Axios.get('http://localhost:8080/inscripcionesapi/index.php?controller=carreras&action=list')
            .then(response => {
                console.log(response);
                setListaCarreras(response.data.data);
            });
    }
    // <div>
//     <select value={genero} onChange={(e) => { setGenero(e.target.value) }}>
//     <option value='-1'>No definido</option>
//     <option value='0'>Femenino</option>
//     <option value='1'>Masculino</option>
// </select>
// </div>

return(
    <Form.Control as="select" {...props}>
        {
            listaCarreras.map(item =>
                <option key={"item-" + item.id} value={item.id} > {item.nombre}  </option>
            )
        }      
    </Form.Control> 
    )
}
