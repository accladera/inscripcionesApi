import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Button, Col, Row, Table } from 'react-bootstrap';
import { Link, useHistory } from 'react-router-dom';

export const ListaMaterias = (props) => {


    let history = useHistory();
    useEffect(() => {
        verificarSesion();
    }, [])
    const verificarSesion = () => {
        if (window.localStorage.length < 1) {
            history.push('/');
        }
        else {
            if (window.localStorage.getItem('type') == 0) {
                history.push('/');
            }
            else {
                traerMaterias();
            }
        }
    }



    const [listaMaterias, setListaMaterias] = useState([]);

    const traerMaterias = () => {
        Axios.get('http://localhost:8080/inscripcionesapi/index.php?controller=materias&action=list')
            .then(response => {
                console.log(response);
                setListaMaterias(response.data.data);
            });
    }


    const eliminarMateria = (id) => {
        Axios.post('http://localhost:8080/inscripcionesapi/index.php?controller=materias&action=delete', { id })
            .then(response => {
                if (response.data.res === "success") {
                    alert('Materia eliminada correctamente');
                    traerMaterias();
                }
                else {
                    console.log(response);
                }
            })
    }

    return (
        <Row className="mt-3">
            <Col>
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NOMBRE</th>
                            <th>SEMESTRE</th>
                            <th>PRECIO</th>
                            <th>CARRERAID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            listaMaterias.map(item =>
                                <tr key={"item-" + item.id} >
                                    <td>{item.id}</td>
                                    <td>{item.nombre}</td>
                                    <td>{item.semestre}</td>
                                    <td>{item.precio} (Bs.) </td>
                                    <td>{item.carreraId}</td>
                                    <td>
                                        <Link className="btn btn-primary" to={'/materias/edit/' + item.id}>Editar</Link>
                                    </td>
                                    <td>
                                        <Button variant="danger" onClick={() => { eliminarMateria(item.id) }} > Eliminar</Button>
                                    </td>
                                </tr>
                            )
                        }
                    </tbody>
                </Table>
            </Col>
        </Row>
    )
}