import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Button, Col, Row, Table } from 'react-bootstrap';
import { Link, useHistory } from 'react-router-dom';

export const ListaInscripciones =(props)=>{
    const [listaInscripciones, setListaInscripciones] = useState([]);
    const [listaUsuarios, setListaUsuarios] = useState([]);
    const [listaCarreras, setListaCarreras] = useState([]);
    const [listaMaterias, setListaMaterias] = useState([]);
    

    let history = useHistory();    
    useEffect(() => {
        verificarSesion();
    }, [])
    const verificarSesion = () => {
        if (window.localStorage.length < 1) {
            history.push('/');
        }
        else{
            traerUsuarios();
            traerCarreras();
            traerMaterias();
            traerInscripciones();
        }
    }
    

    const traerInscripciones = () => {
        Axios.get('http://localhost:8080/inscripcionesapi/index.php?controller=inscripciones&action=list')
            .then(response => {
                console.log(response);
                setListaInscripciones(response.data.data);
            });
    }    
    const traerUsuarios = () => {
        Axios.get('http://localhost:8080/inscripcionesapi/index.php?controller=usuarios&action=list')
            .then(response => {
                console.log(response);
                setListaUsuarios(response.data.data);
            });
    }    
    const traerCarreras = () => {
        Axios.get('http://localhost:8080/inscripcionesapi/index.php?controller=carreras&action=list')
            .then(response => {
                console.log(response);
                setListaCarreras(response.data.data);
            });
    }
    const traerMaterias = () => {
        Axios.get('http://localhost:8080/inscripcionesapi/index.php?controller=materias&action=list')
            .then(response => {
                console.log(response);
                setListaMaterias(response.data.data);
            });
    }
    
    const eliminarInscripcion = (id) => {
        Axios.post('http://localhost:8080/inscripcionesapi/index.php?controller=inscripciones&action=delete', { id })
            .then(response => {
                if (response.data.res === "success") {
                    alert('Inscripcion quitada');
                    traerInscripciones();
                }
                else {
                    console.log(response);
                }
            })
    }


    

    return (
        <Row className="mt-3">
            <Col>
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>USUARIOID</th>
                            <th>MATERIAID</th>                           
                            <th>CARRERAID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            listaInscripciones.map(item =>
                                <tr key={"item-" + item.id} >
                                    <td>{item.id}</td>
                                    <td>{item.usuarioId}</td>
                                    <td>{item.materiaId}</td>
                                    <td>{item.carreraId}</td>
                                    <td>
                                        <Link className="btn btn-primary" to={'/inscripciones/edit/' + item.id}>editar</Link>
                                    </td>
                                    <td>
                                        <Button variant="danger" onClick={() => { eliminarInscripcion(item.id) }} > Eliminar</Button>
                                    </td>
                                </tr>
                            )
                        }
                    </tbody>
                </Table>
            </Col>
        </Row>
    )
}