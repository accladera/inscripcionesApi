import React, { useEffect } from 'react';
import { Card, Col, Row } from 'react-bootstrap';
import { useHistory } from 'react-router-dom';

export const Home = (props) => {

    let history = useHistory();
    useEffect(() => {
        verificarSesion();
    }, [])

    const verificarSesion = () => {
        if (window.localStorage.length < 1) {
            history.push('/');
        }
    }



    return (
        <Row className="mt-3">
            <Col>
                <Card bg="primary" text="white" className="text-center p-3">
                    <blockquote className="blockquote mb-0 card-body">
                        <h1>Inscripciones APP</h1>
                    </blockquote>
                </Card>
            </Col>
        </Row>
    )
}