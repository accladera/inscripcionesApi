import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Col, Form, Row } from 'react-bootstrap';
import { useHistory } from 'react-router-dom';

import { MyInput } from '../components/My-input';
import { MyLabel } from '../components/My-label';
import { MySubmit } from '../components/My-Submit';

export const FormularioSesion = (props) => {
    let history = useHistory();
    let id = props.match ? props.match.params.id : 0;

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    useEffect(() => {
        verificarSesion();
    }, [])

    const verificarSesion = () => {
        if (window.localStorage.length > 0) {
            history.push('/usuarios');
        }
    }
    const clickEntrar = () => {
            Axios.get('http://localhost:8080/inscripcionesapi/index.php?controller=usuarios&action=detailEmail&email=' + email)
            .then(response => {
                if (response.data.res === "success") {
                    const usuario = response.data.data;
                    if (usuario.password === password) {
                        console.log(usuario);
                        console.log(response);
                        window.localStorage.setItem('session', JSON.stringify(usuario));
  
                        history.push('/usuarios');
                    }
                    else {
                        alert('Usuario email/contraseña incorrecto');
                    }
                } else {
                    alert('Usuario email/contraseña incorrecto');
                }
            });
    }
    return (
        <Row className="mt-3">
            <Col xs={{ span: 4, offset: 1 }}>
                <Form.Group>
                    <MyLabel text='Email de usuario:'></MyLabel>
                    <MyInput value={email} placeholder="Escribe su email" onChange={(e) => { setEmail(e.target.value) }} ></MyInput>
                </Form.Group>
                <Form.Group>
                    <MyLabel text='Password:'></MyLabel>
                    <MyInput input="password" value={password} placeholder="Escribe su contraseña" onChange={(e) => { setPassword(e.target.value) }} ></MyInput>
                </Form.Group>
                <Form.Group>
                    <MySubmit onClick={clickEntrar} ></MySubmit>
                </Form.Group>
            </Col>
        </Row>
    )

}