<?php
include 'vendor\autoload.php';
// ctrl + R = reemplazar texto