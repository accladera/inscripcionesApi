<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" src="./vendor/twbs/bootstrap/dist/js/bootstrap.bundle.js"></script>
</body>
</html>