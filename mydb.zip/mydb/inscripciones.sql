-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-09-2020 a las 18:59:45
-- Versión del servidor: 8.0.20
-- Versión de PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inscripciones`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_carrera_delete` (IN `p_id` INT)  NO SQL
DELETE FROM carrera  WHERE id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_carrera_insert` (IN `p_nombre` VARCHAR(200))  NO SQL
BEGIN
INSERT INTO carrera(nombre)
VALUES (p_nombre);
SELECT LAST_INSERT_ID() as lastId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_carrera_search` (IN `p_busqueda` VARCHAR(200))  NO SQL
SELECT 
    id,nombre
                FROM carrera 
                WHERE  nombre LIKE CONCAT('%',p_busqueda,'%')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_carrera_select` (IN `p_id` INT)  NO SQL
SELECT id, nombre FROM carrera WHERE  id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_carrera_selectAll` ()  NO SQL
SELECT id,nombre
FROM carrera$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_carrera_update` (IN `p_nombre` VARCHAR(200), IN `p_id` INT)  NO SQL
UPDATE carrera 
            SET
                nombre = p_nombre
            WHERE
                id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inscripcion_delete` (IN `p_id` INT)  NO SQL
DELETE FROM inscripcion  WHERE id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inscripcion_insert` (IN `p_usuarioId` INT, IN `p_carreraId` INT, IN `p_materiaId` INT)  NO SQL
BEGIN
INSERT INTO inscripcion(usuarioId,carreraId,materiaId)
VALUES (p_usuarioId,p_carreraId,p_materiaId);
SELECT LAST_INSERT_ID() as lastId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inscripcion_search` (IN `p_busqueda` INT(200))  NO SQL
SELECT 
    id, usuarioId, carreraId, materiaId
                FROM inscripcion 
                WHERE  usuarioId  = p_busqueda 		
                OR carreraId = p_busqueda
                OR materiaId = p_busqueda$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inscripcion_select` (IN `p_id` INT)  NO SQL
SELECT id,usuarioId , carreraId, materiaId
            FROM inscripcion WHERE  id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inscripcion_selectAll` ()  NO SQL
SELECT id,usuarioId, carreraId,materiaId
FROM inscripcion$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inscripcion_update` (IN `p_usuarioId` INT, IN `p_carreraId` INT, IN `p_materiaId` INT, IN `p_id` INT)  NO SQL
UPDATE inscripcion 
            SET
            	usuarioId = p_usuarioId,
                carreraId = p_carreraId,
                materiaId = p_materiaId
            WHERE
                id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_materia_delete` (IN `p_id` INT)  NO SQL
DELETE FROM materia  WHERE id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_materia_insert` (IN `p_nombre` VARCHAR(200), IN `p_semestre` VARCHAR(200), IN `p_precio` INT, IN `p_carreraId` INT)  NO SQL
BEGIN
INSERT INTO materia(nombre, semestre, precio, carreraId)
VALUES (p_nombre, p_semestre, p_precio ,p_carreraId);
SELECT LAST_INSERT_ID() as lastId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_materia_search` (IN `p_busqueda` INT(200))  NO SQL
SELECT 
    id, nombre, semestre,precio, carreraId
    FROM materia 
                WHERE  nombre LIKE CONCAT('%',p_busqueda,'%') 
                OR semestre LIKE CONCAT('%',p_busqueda,'%')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_materia_select` (IN `p_id` INT)  NO SQL
SELECT id, nombre,semestre, precio , carreraId
            FROM materia WHERE  id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_materia_selectAll` ()  NO SQL
SELECT id,nombre, semestre, precio, carreraId
FROM materia$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_materia_update` (IN `p_nombre` VARCHAR(200), IN `p_semestre` VARCHAR(200), IN `p_precio` INT, IN `p_carreraId` INT, IN `p_id` INT)  NO SQL
UPDATE materia 
            SET
                nombre = p_nombre,
                semestre = p_semestre,
                precio  = p_precio,
                carreraId = p_carreraId
            WHERE
                id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_delete` (IN `p_id` INT)  NO SQL
DELETE FROM usuario  WHERE id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_insert` (IN `p_nombreCompleto` VARCHAR(200), IN `p_email` VARCHAR(200), IN `p_password` VARCHAR(200), IN `p_tipoUsuario` INT, IN `p_carreraId` INT)  NO SQL
BEGIN
INSERT INTO usuario(nombreCompleto,email,password,tipoUsuario,carreraId)
VALUES (p_nombreCompleto,
        p_email,
        p_password, 
        p_tipoUsuario,
        p_carreraId);
SELECT LAST_INSERT_ID() as lastId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_search` (IN `p_busqueda` VARCHAR(200))  NO SQL
SELECT 
    id, nombreCompleto, email, password, tipoUsuario, carreraId
                FROM usuario 
                WHERE  nombreCompleto LIKE CONCAT('%',p_busqueda,'%') 
                OR email LIKE CONCAT('%',p_busqueda,'%')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_searchByEmail` (IN `p_email` VARCHAR(200))  NO SQL
SELECT 
    id, nombreCompleto, email, password, tipoUsuario, carreraId
                FROM usuario 
                WHERE  email LIKE p_email$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_select` (IN `p_id` INT)  NO SQL
SELECT id, nombreCompleto, email, password, tipoUsuario, carreraId
            FROM usuario WHERE  id = p_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_selectAll` ()  NO SQL
SELECT id, nombreCompleto, email, password, tipoUsuario, carreraId
FROM usuario$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_update` (IN `p_nombreCompleto` VARCHAR(200), IN `p_email` VARCHAR(200), IN `p_password` VARCHAR(200), IN `p_tipoUsuario` INT, IN `p_carreraId` INT, IN `p_id` INT)  NO SQL
UPDATE usuario 
            SET
                nombreCompleto = p_nombreCompleto,
                email = p_email,
                password = p_password,
                tipoUsuario = p_tipoUsuario,
                carreraId = p_carreraId
                
            WHERE
                id = p_id$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrera`
--

CREATE TABLE `carrera` (
  `id` int NOT NULL,
  `nombre` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `carrera`
--

INSERT INTO `carrera` (`id`, `nombre`) VALUES
(1, 'Carrera 0'),
(2, 'Veterinaria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inscripcion`
--

CREATE TABLE `inscripcion` (
  `id` int NOT NULL,
  `usuarioId` int NOT NULL,
  `carreraId` int NOT NULL,
  `materiaId` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE `materia` (
  `id` int NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `semestre` varchar(200) NOT NULL,
  `precio` int NOT NULL,
  `carreraId` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`id`, `nombre`, `semestre`, `precio`, `carreraId`) VALUES
(1, 'Ingenieria Web II', 'Sexto', 1200, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int NOT NULL,
  `nombreCompleto` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `tipoUsuario` int NOT NULL,
  `carreraId` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombreCompleto`, `email`, `password`, `tipoUsuario`, `carreraId`) VALUES
(3, 'Carolina', 'c24@gmail.com', '123', 0, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrera`
--
ALTER TABLE `carrera`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inscripcion`
--
ALTER TABLE `inscripcion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_inscripcion_usuario1_idx` (`usuarioId`),
  ADD KEY `fk_inscripcion_carrera1_idx` (`carreraId`),
  ADD KEY `fk_inscripcion_materia1_idx` (`materiaId`);

--
-- Indices de la tabla `materia`
--
ALTER TABLE `materia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_materia_carrera1_idx` (`carreraId`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuario_carrera1_idx` (`carreraId`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carrera`
--
ALTER TABLE `carrera`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `inscripcion`
--
ALTER TABLE `inscripcion`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `materia`
--
ALTER TABLE `materia`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `inscripcion`
--
ALTER TABLE `inscripcion`
  ADD CONSTRAINT `fk_inscripcion_carrera1` FOREIGN KEY (`carreraId`) REFERENCES `carrera` (`id`),
  ADD CONSTRAINT `fk_inscripcion_materia1` FOREIGN KEY (`materiaId`) REFERENCES `materia` (`id`),
  ADD CONSTRAINT `fk_inscripcion_usuario1` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`id`);

--
-- Filtros para la tabla `materia`
--
ALTER TABLE `materia`
  ADD CONSTRAINT `fk_materia_carrera` FOREIGN KEY (`carreraId`) REFERENCES `carrera` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `fk_usuario_carrera1` FOREIGN KEY (`carreraId`) REFERENCES `carrera` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
